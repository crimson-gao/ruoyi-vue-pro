package cn.iocoder.yudao.adminserver.modules.bus.dal.dataobject.material;

import lombok.*;
import java.util.*;
import com.baomidou.mybatisplus.annotation.*;
import cn.iocoder.yudao.framework.mybatis.core.dataobject.BaseDO;

/**
 * 物料编码 DO
 *
 * @author crimson
 */
@TableName("bus_material")
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BusMaterialDO extends BaseDO {

    /**
     * id
     */
    @TableId
    private Long id;
    /**
     * 物料编码
     */
    private String code;
    /**
     * 名称
     */
    private String name;
    /**
     * 规格
     */
    private String spec;
    /**
     * 备注
     */
    private String note;

}
