package cn.iocoder.yudao.adminserver.modules.bus.service.material;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.mock.mockito.MockBean;

import javax.annotation.Resource;

import cn.iocoder.yudao.adminserver.BaseDbUnitTest;
import cn.iocoder.yudao.adminserver.modules.bus.service.material.impl.BusMaterialServiceImpl;
import cn.iocoder.yudao.adminserver.modules.bus.controller.material.vo.*;
import cn.iocoder.yudao.adminserver.modules.bus.dal.dataobject.material.BusMaterialDO;
import cn.iocoder.yudao.adminserver.modules.bus.dal.mysql.material.BusMaterialMapper;
import cn.iocoder.yudao.framework.common.pojo.PageResult;

import javax.annotation.Resource;
import org.springframework.context.annotation.Import;
import java.util.*;

import static cn.hutool.core.util.RandomUtil.*;
import static cn.iocoder.yudao.adminserver.modules.bus.enums.BusErrorCodeConstants.*;
import static cn.iocoder.yudao.framework.test.core.util.AssertUtils.*;
import static cn.iocoder.yudao.framework.test.core.util.RandomUtils.*;
import static cn.iocoder.yudao.framework.common.util.object.ObjectUtils.*;
import static cn.iocoder.yudao.framework.common.util.date.DateUtils.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
* {@link BusMaterialServiceImpl} 的单元测试类
*
* @author crimson
*/
@Import(BusMaterialServiceImpl.class)
public class BusMaterialServiceTest extends BaseDbUnitTest {

    @Resource
    private BusMaterialServiceImpl materialService;

    @Resource
    private BusMaterialMapper materialMapper;

    @Test
    public void testCreateMaterial_success() {
        // 准备参数
        BusMaterialCreateReqVO reqVO = randomPojo(BusMaterialCreateReqVO.class);

        // 调用
        Long materialId = materialService.createMaterial(reqVO);
        // 断言
        assertNotNull(materialId);
        // 校验记录的属性是否正确
        BusMaterialDO material = materialMapper.selectById(materialId);
        assertPojoEquals(reqVO, material);
    }

    @Test
    public void testUpdateMaterial_success() {
        // mock 数据
        BusMaterialDO dbMaterial = randomPojo(BusMaterialDO.class);
        materialMapper.insert(dbMaterial);// @Sql: 先插入出一条存在的数据
        // 准备参数
        BusMaterialUpdateReqVO reqVO = randomPojo(BusMaterialUpdateReqVO.class, o -> {
            o.setId(dbMaterial.getId()); // 设置更新的 ID
        });

        // 调用
        materialService.updateMaterial(reqVO);
        // 校验是否更新正确
        BusMaterialDO material = materialMapper.selectById(reqVO.getId()); // 获取最新的
        assertPojoEquals(reqVO, material);
    }

    @Test
    public void testUpdateMaterial_notExists() {
        // 准备参数
        BusMaterialUpdateReqVO reqVO = randomPojo(BusMaterialUpdateReqVO.class);

        // 调用, 并断言异常
        assertServiceException(() -> materialService.updateMaterial(reqVO), MATERIAL_NOT_EXISTS);
    }

    @Test
    public void testDeleteMaterial_success() {
        // mock 数据
        BusMaterialDO dbMaterial = randomPojo(BusMaterialDO.class);
        materialMapper.insert(dbMaterial);// @Sql: 先插入出一条存在的数据
        // 准备参数
        Long id = dbMaterial.getId();

        // 调用
        materialService.deleteMaterial(id);
       // 校验数据不存在了
       assertNull(materialMapper.selectById(id));
    }

    @Test
    public void testDeleteMaterial_notExists() {
        // 准备参数
        Long id = randomLongId();

        // 调用, 并断言异常
        assertServiceException(() -> materialService.deleteMaterial(id), MATERIAL_NOT_EXISTS);
    }

    @Test // TODO 请修改 null 为需要的值
    public void testGetMaterialPage() {
       // mock 数据
       BusMaterialDO dbMaterial = randomPojo(BusMaterialDO.class, o -> { // 等会查询到
           o.setCode(null);
           o.setName(null);
           o.setCreator(null);
           o.setCreateTime(null);
       });
       materialMapper.insert(dbMaterial);
       // 测试 code 不匹配
       materialMapper.insert(cloneIgnoreId(dbMaterial, o -> o.setCode(null)));
       // 测试 name 不匹配
       materialMapper.insert(cloneIgnoreId(dbMaterial, o -> o.setName(null)));
       // 测试 creator 不匹配
       materialMapper.insert(cloneIgnoreId(dbMaterial, o -> o.setCreator(null)));
       // 测试 createTime 不匹配
       materialMapper.insert(cloneIgnoreId(dbMaterial, o -> o.setCreateTime(null)));
       // 准备参数
       BusMaterialPageReqVO reqVO = new BusMaterialPageReqVO();
       reqVO.setCode(null);
       reqVO.setName(null);
       reqVO.setCreator(null);
       reqVO.setBeginCreateTime(null);
       reqVO.setEndCreateTime(null);

       // 调用
       PageResult<BusMaterialDO> pageResult = materialService.getMaterialPage(reqVO);
       // 断言
       assertEquals(1, pageResult.getTotal());
       assertEquals(1, pageResult.getList().size());
       assertPojoEquals(dbMaterial, pageResult.getList().get(0));
    }

    @Test // TODO 请修改 null 为需要的值
    public void testGetMaterialList() {
       // mock 数据
       BusMaterialDO dbMaterial = randomPojo(BusMaterialDO.class, o -> { // 等会查询到
           o.setCode(null);
           o.setName(null);
           o.setCreator(null);
           o.setCreateTime(null);
       });
       materialMapper.insert(dbMaterial);
       // 测试 code 不匹配
       materialMapper.insert(cloneIgnoreId(dbMaterial, o -> o.setCode(null)));
       // 测试 name 不匹配
       materialMapper.insert(cloneIgnoreId(dbMaterial, o -> o.setName(null)));
       // 测试 creator 不匹配
       materialMapper.insert(cloneIgnoreId(dbMaterial, o -> o.setCreator(null)));
       // 测试 createTime 不匹配
       materialMapper.insert(cloneIgnoreId(dbMaterial, o -> o.setCreateTime(null)));
       // 准备参数
       BusMaterialExportReqVO reqVO = new BusMaterialExportReqVO();
       reqVO.setCode(null);
       reqVO.setName(null);
       reqVO.setCreator(null);
       reqVO.setBeginCreateTime(null);
       reqVO.setEndCreateTime(null);

       // 调用
       List<BusMaterialDO> list = materialService.getMaterialList(reqVO);
       // 断言
       assertEquals(1, list.size());
       assertPojoEquals(dbMaterial, list.get(0));
    }

}
