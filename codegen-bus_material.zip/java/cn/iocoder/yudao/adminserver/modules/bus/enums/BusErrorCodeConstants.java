// ========== 物料编码 TODO 补充编号 ==========
ErrorCode MATERIAL_NOT_EXISTS = new ErrorCode(TODO 补充编号, "物料编码不存在");
