package cn.iocoder.yudao.adminserver.modules.bus.controller.projectManifest.vo;

import lombok.*;
import java.util.*;
import io.swagger.annotations.*;

import com.alibaba.excel.annotation.ExcelProperty;

/**
 * 项目物料清单 Excel VO
 *
 * @author crimson
 */
@Data
public class BusProjectManifestExcelVO {

    @ExcelProperty("id")
    private Long id;

    @ExcelProperty("所属项目")
    private Long projectId;

    @ExcelProperty("物料编码")
    private Long materialId;

    @ExcelProperty("申报数量")
    private String requiredQuantity;

    @ExcelProperty("到货数量")
    private String receivedQuantity;

    @ExcelProperty("创建时间")
    private Date createTime;

    @ExcelProperty("更新时间")
    private Date updateTime;

    @ExcelProperty("创建者")
    private String creator;

    @ExcelProperty("备注")
    private String note;

    @ExcelProperty("更新者")
    private String updater;

}
