package cn.iocoder.yudao.adminserver.modules.bus.service.projectManifest.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import org.springframework.validation.annotation.Validated;

import java.util.*;
import cn.iocoder.yudao.adminserver.modules.bus.controller.projectManifest.vo.*;
import cn.iocoder.yudao.adminserver.modules.bus.dal.dataobject.projectManifest.BusProjectManifestDO;
import cn.iocoder.yudao.framework.common.pojo.PageResult;

import cn.iocoder.yudao.adminserver.modules.bus.convert.projectManifest.BusProjectManifestConvert;
import cn.iocoder.yudao.adminserver.modules.bus.dal.mysql.projectManifest.BusProjectManifestMapper;
import cn.iocoder.yudao.adminserver.modules.bus.service.projectManifest.BusProjectManifestService;

import static cn.iocoder.yudao.framework.common.exception.util.ServiceExceptionUtil.exception;
import static cn.iocoder.yudao.adminserver.modules.bus.enums.BusErrorCodeConstants.*;

/**
 * 项目物料清单 Service 实现类
 *
 * @author crimson
 */
@Service
@Validated
public class BusProjectManifestServiceImpl implements BusProjectManifestService {

    @Resource
    private BusProjectManifestMapper projectManifestMapper;

    @Override
    public Long createProjectManifest(BusProjectManifestCreateReqVO createReqVO) {
        // 插入
        BusProjectManifestDO projectManifest = BusProjectManifestConvert.INSTANCE.convert(createReqVO);
        projectManifestMapper.insert(projectManifest);
        // 返回
        return projectManifest.getId();
    }

    @Override
    public void updateProjectManifest(BusProjectManifestUpdateReqVO updateReqVO) {
        // 校验存在
        this.validateProjectManifestExists(updateReqVO.getId());
        // 更新
        BusProjectManifestDO updateObj = BusProjectManifestConvert.INSTANCE.convert(updateReqVO);
        projectManifestMapper.updateById(updateObj);
    }

    @Override
    public void deleteProjectManifest(Long id) {
        // 校验存在
        this.validateProjectManifestExists(id);
        // 删除
        projectManifestMapper.deleteById(id);
    }

    private void validateProjectManifestExists(Long id) {
        if (projectManifestMapper.selectById(id) == null) {
            throw exception(PROJECT_MANIFEST_NOT_EXISTS);
        }
    }

    @Override
    public BusProjectManifestDO getProjectManifest(Long id) {
        return projectManifestMapper.selectById(id);
    }

    @Override
    public List<BusProjectManifestDO> getProjectManifestList(Collection<Long> ids) {
        return projectManifestMapper.selectBatchIds(ids);
    }

    @Override
    public PageResult<BusProjectManifestDO> getProjectManifestPage(BusProjectManifestPageReqVO pageReqVO) {
        return projectManifestMapper.selectPage(pageReqVO);
    }

    @Override
    public List<BusProjectManifestDO> getProjectManifestList(BusProjectManifestExportReqVO exportReqVO) {
        return projectManifestMapper.selectList(exportReqVO);
    }

}
