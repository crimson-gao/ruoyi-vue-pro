package cn.iocoder.yudao.adminserver.modules.bus.service.projectManifest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.mock.mockito.MockBean;

import javax.annotation.Resource;

import cn.iocoder.yudao.adminserver.BaseDbUnitTest;
import cn.iocoder.yudao.adminserver.modules.bus.service.projectManifest.impl.BusProjectManifestServiceImpl;
import cn.iocoder.yudao.adminserver.modules.bus.controller.projectManifest.vo.*;
import cn.iocoder.yudao.adminserver.modules.bus.dal.dataobject.projectManifest.BusProjectManifestDO;
import cn.iocoder.yudao.adminserver.modules.bus.dal.mysql.projectManifest.BusProjectManifestMapper;
import cn.iocoder.yudao.framework.common.pojo.PageResult;

import javax.annotation.Resource;
import org.springframework.context.annotation.Import;
import java.util.*;

import static cn.hutool.core.util.RandomUtil.*;
import static cn.iocoder.yudao.adminserver.modules.bus.enums.BusErrorCodeConstants.*;
import static cn.iocoder.yudao.framework.test.core.util.AssertUtils.*;
import static cn.iocoder.yudao.framework.test.core.util.RandomUtils.*;
import static cn.iocoder.yudao.framework.common.util.object.ObjectUtils.*;
import static cn.iocoder.yudao.framework.common.util.date.DateUtils.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
* {@link BusProjectManifestServiceImpl} 的单元测试类
*
* @author crimson
*/
@Import(BusProjectManifestServiceImpl.class)
public class BusProjectManifestServiceTest extends BaseDbUnitTest {

    @Resource
    private BusProjectManifestServiceImpl projectManifestService;

    @Resource
    private BusProjectManifestMapper projectManifestMapper;

    @Test
    public void testCreateProjectManifest_success() {
        // 准备参数
        BusProjectManifestCreateReqVO reqVO = randomPojo(BusProjectManifestCreateReqVO.class);

        // 调用
        Long projectManifestId = projectManifestService.createProjectManifest(reqVO);
        // 断言
        assertNotNull(projectManifestId);
        // 校验记录的属性是否正确
        BusProjectManifestDO projectManifest = projectManifestMapper.selectById(projectManifestId);
        assertPojoEquals(reqVO, projectManifest);
    }

    @Test
    public void testUpdateProjectManifest_success() {
        // mock 数据
        BusProjectManifestDO dbProjectManifest = randomPojo(BusProjectManifestDO.class);
        projectManifestMapper.insert(dbProjectManifest);// @Sql: 先插入出一条存在的数据
        // 准备参数
        BusProjectManifestUpdateReqVO reqVO = randomPojo(BusProjectManifestUpdateReqVO.class, o -> {
            o.setId(dbProjectManifest.getId()); // 设置更新的 ID
        });

        // 调用
        projectManifestService.updateProjectManifest(reqVO);
        // 校验是否更新正确
        BusProjectManifestDO projectManifest = projectManifestMapper.selectById(reqVO.getId()); // 获取最新的
        assertPojoEquals(reqVO, projectManifest);
    }

    @Test
    public void testUpdateProjectManifest_notExists() {
        // 准备参数
        BusProjectManifestUpdateReqVO reqVO = randomPojo(BusProjectManifestUpdateReqVO.class);

        // 调用, 并断言异常
        assertServiceException(() -> projectManifestService.updateProjectManifest(reqVO), PROJECT_MANIFEST_NOT_EXISTS);
    }

    @Test
    public void testDeleteProjectManifest_success() {
        // mock 数据
        BusProjectManifestDO dbProjectManifest = randomPojo(BusProjectManifestDO.class);
        projectManifestMapper.insert(dbProjectManifest);// @Sql: 先插入出一条存在的数据
        // 准备参数
        Long id = dbProjectManifest.getId();

        // 调用
        projectManifestService.deleteProjectManifest(id);
       // 校验数据不存在了
       assertNull(projectManifestMapper.selectById(id));
    }

    @Test
    public void testDeleteProjectManifest_notExists() {
        // 准备参数
        Long id = randomLongId();

        // 调用, 并断言异常
        assertServiceException(() -> projectManifestService.deleteProjectManifest(id), PROJECT_MANIFEST_NOT_EXISTS);
    }

    @Test // TODO 请修改 null 为需要的值
    public void testGetProjectManifestPage() {
       // mock 数据
       BusProjectManifestDO dbProjectManifest = randomPojo(BusProjectManifestDO.class, o -> { // 等会查询到
           o.setProjectId(null);
           o.setMaterialId(null);
           o.setCreateTime(null);
       });
       projectManifestMapper.insert(dbProjectManifest);
       // 测试 projectId 不匹配
       projectManifestMapper.insert(cloneIgnoreId(dbProjectManifest, o -> o.setProjectId(null)));
       // 测试 materialId 不匹配
       projectManifestMapper.insert(cloneIgnoreId(dbProjectManifest, o -> o.setMaterialId(null)));
       // 测试 createTime 不匹配
       projectManifestMapper.insert(cloneIgnoreId(dbProjectManifest, o -> o.setCreateTime(null)));
       // 准备参数
       BusProjectManifestPageReqVO reqVO = new BusProjectManifestPageReqVO();
       reqVO.setProjectId(null);
       reqVO.setMaterialId(null);
       reqVO.setBeginCreateTime(null);
       reqVO.setEndCreateTime(null);

       // 调用
       PageResult<BusProjectManifestDO> pageResult = projectManifestService.getProjectManifestPage(reqVO);
       // 断言
       assertEquals(1, pageResult.getTotal());
       assertEquals(1, pageResult.getList().size());
       assertPojoEquals(dbProjectManifest, pageResult.getList().get(0));
    }

    @Test // TODO 请修改 null 为需要的值
    public void testGetProjectManifestList() {
       // mock 数据
       BusProjectManifestDO dbProjectManifest = randomPojo(BusProjectManifestDO.class, o -> { // 等会查询到
           o.setProjectId(null);
           o.setMaterialId(null);
           o.setCreateTime(null);
       });
       projectManifestMapper.insert(dbProjectManifest);
       // 测试 projectId 不匹配
       projectManifestMapper.insert(cloneIgnoreId(dbProjectManifest, o -> o.setProjectId(null)));
       // 测试 materialId 不匹配
       projectManifestMapper.insert(cloneIgnoreId(dbProjectManifest, o -> o.setMaterialId(null)));
       // 测试 createTime 不匹配
       projectManifestMapper.insert(cloneIgnoreId(dbProjectManifest, o -> o.setCreateTime(null)));
       // 准备参数
       BusProjectManifestExportReqVO reqVO = new BusProjectManifestExportReqVO();
       reqVO.setProjectId(null);
       reqVO.setMaterialId(null);
       reqVO.setBeginCreateTime(null);
       reqVO.setEndCreateTime(null);

       // 调用
       List<BusProjectManifestDO> list = projectManifestService.getProjectManifestList(reqVO);
       // 断言
       assertEquals(1, list.size());
       assertPojoEquals(dbProjectManifest, list.get(0));
    }

}
